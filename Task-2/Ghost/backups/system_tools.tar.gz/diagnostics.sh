#!/bin/bash
# This script prints a normal message to stdout and a secret key to stderr.
echo "System check complete. All systems nominal."
echo "ERR_KEY_84B1D" >&2
